# TODO LIST

* [X] Validar ciudad de origen igual a la de destino
* [X] Mostrar ciudades: cordoba capital, rio primero, villa carlos paz
* [X] Mostrar todos los minutos
* [X] Poner máximo de 280 caracteres, min de 5 donde es requerido
* [X] Mostrar pantalla de resumen
* [X] Minimo de 1 hora para la entrega programada
* [X] Considerar el usuario logueado
* [X] Mostrar foto del producto
* [X] Mostrar mapa y dirección escrita